gelement* readGrammar(gelement* G);
