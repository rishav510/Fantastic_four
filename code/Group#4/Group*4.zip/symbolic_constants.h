#define MAX_SRC_WORD 100					//max length of a word
#define MAX_READ_LINE 256
#define MAX_WORD_LENGTH 100
