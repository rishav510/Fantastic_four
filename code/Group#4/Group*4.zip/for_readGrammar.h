int count_lines(FILE*);

gnode* create_gnode();



gnode* add_to_end(gnode*);
