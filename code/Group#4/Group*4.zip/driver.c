#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "parse_tree_node.h"
#include "tokeniseSourceCode.h"
#include "readGrammar.h"
#include "stack.h"
#include "data_structures_for_readGrammar.h"

int main(){
	gelement* starting_rule;
	starting_rule = readGrammar(starting_rule); //reading the grammar from grammar.txt
	parse_tree_node* root;
	t_node* token_stream_head = tokeniseSourceCode("src.txt", token_stream_head);
	while(1){

		int input ;
		scanf("%d",&input);

		switch(input){

			case 0: 
			       exit(1);
			       break;

			case 1:
			       root = createParseTree(root,token_stream_head,starting_rule); //errors at compile time.
			       break;

			case 2:
				printf("\ntraverse the parse tree and construct type expression table Also print the type errors while traversing the parse tree and accessing the typeExpressionTable."); //implementation not done
				break;

			case 3:
				printf("print parse tree in specified format"); //implementation not done
			       break;

			case 4:
			 	printf("Print typeExpressionTable in the specified format."); // implementation incomplete
			 	break;
			 


		}
	}
	return 0;
}
