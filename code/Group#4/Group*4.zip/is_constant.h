int is_constant(char* token_string) ;
